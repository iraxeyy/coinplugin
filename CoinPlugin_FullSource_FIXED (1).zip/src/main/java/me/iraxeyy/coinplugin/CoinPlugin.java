package me.iraxeyy.coinplugin;

import org.bukkit.plugin.java.JavaPlugin;

public class CoinPlugin extends JavaPlugin {
    @Override
    public void onEnable() {
        getLogger().info("✅ CoinPlugin enabled!");
    }
}
