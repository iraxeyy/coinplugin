
# CoinPlugin

A free Minecraft + Discord coin economy plugin. Supports:

- /coins and /leaderboard in Minecraft
- /daily, /trivia, /coinflip, /stats and /link in Discord
- Scoreboard display of player name, coins, Discord
- Discord + Minecraft account linking
- Built-in Discord bot (JDA)
- Configurable bot token via `config.yml`

## Setup

1. Edit `src/main/resources/config.yml` and paste your Discord bot token.
2. Build the plugin using:

```
mvn clean package
```

3. Upload `target/CoinPlugin-1.0.jar` to your Minecraft server.

## Commands

### Minecraft
- `/coins` - Show your coin balance
- `/link` - Get a 6-digit code to link with Discord
- `/leaderboard` - See top players

### Discord
- `/daily` - Claim 5 coins daily
- `/trivia` - Answer questions to earn coins
- `/coinflip` - Gamble coins
- `/stats` - View your coin stats
- `/link code:<6-digit>` - Link with your Minecraft account

## License

Open-source for public use. No premium lock features.
