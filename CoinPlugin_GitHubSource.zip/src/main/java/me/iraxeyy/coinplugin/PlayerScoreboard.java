
package me.iraxeyy.coinplugin;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scoreboard.*;

public class PlayerScoreboard {

    public static void show(Player player) {
        update(player);

        new BukkitRunnable() {
            @Override
            public void run() {
                if (!player.isOnline()) {
                    cancel();
                    return;
                }
                update(player);
            }
        }.runTaskTimer(CoinPlugin.instance, 0, 100);
    }

    private static void update(Player player) {
        ScoreboardManager manager = Bukkit.getScoreboardManager();
        if (manager == null) return;
        Scoreboard board = manager.getNewScoreboard();
        Objective obj = board.getObjective("coins");
        if (obj != null) obj.unregister();

        obj = board.registerNewObjective("coins", "dummy", "§l§6⚡ Player Info ⚡");
        obj.setDisplaySlot(DisplaySlot.SIDEBAR);

        obj.getScore("§7 ").setScore(6);
        obj.getScore("§fName: §b" + player.getName()).setScore(5);
        int coins = CoinPlugin.coinManager.getCoins(player.getUniqueId());
        obj.getScore("§fCoins: §a" + coins).setScore(4);
        String discord = CoinPlugin.linkManager.getDiscordId(player.getUniqueId());
        if (discord == null) discord = "§cNot linked";
        obj.getScore("§fDiscord: §d" + discord).setScore(3);
        obj.getScore("§fRank: §eDefault").setScore(2);
        obj.getScore("§7  ").setScore(1);

        player.setScoreboard(board);
    }
}
