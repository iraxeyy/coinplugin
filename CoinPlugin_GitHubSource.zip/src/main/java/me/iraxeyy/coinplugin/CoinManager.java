// CoinManager.java
package me.iraxeyy.coinplugin;

import java.util.HashMap;
import java.util.UUID;

public class CoinManager {
    private final HashMap<UUID, Integer> coins = new HashMap<>();

    public int getCoins(UUID uuid) {
        return coins.getOrDefault(uuid, 0);
    }

    public void addCoins(UUID uuid, int amount) {
        coins.put(uuid, getCoins(uuid) + amount);
    }

    public void removeCoins(UUID uuid, int amount) {
        coins.put(uuid, Math.max(0, getCoins(uuid) - amount));
    }
}
