
package me.iraxeyy.coinplugin.Discord;

import me.iraxeyy.coinplugin.CoinPlugin;
import me.iraxeyy.coinplugin.PlayerStats;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import net.dv8tion.jda.api.interactions.commands.OptionMapping;

import java.util.UUID;
import java.util.Random;

public class SlashHandler extends ListenerAdapter {

    @Override
    public void onSlashCommandInteraction(SlashCommandInteractionEvent event) {
        String discordId = event.getUser().getId();
        UUID uuid = CoinPlugin.linkManager.getMinecraftUUID(discordId);

        switch (event.getName()) {
            case "daily":
                if (uuid != null) {
                    CoinPlugin.coinManager.addCoins(uuid, 5);
                    PlayerStats.recordEarn(uuid, 5);
                    event.reply("✅ You received your daily 5 coins!").setEphemeral(true).queue();
                } else {
                    event.reply("❌ You're not linked! Use /link in Minecraft.").setEphemeral(true).queue();
                }
                break;

            case "trivia":
                if (uuid == null) {
                    event.reply("❌ You're not linked!").setEphemeral(true).queue();
                    return;
                }
                CoinPlugin.coinManager.addCoins(uuid, 10);
                PlayerStats.recordEarn(uuid, 10);
                event.reply("🧠 Trivia answered! You earned 10 coins.").setEphemeral(true).queue();
                break;

            case "coinflip":
                if (uuid == null) {
                    event.reply("❌ You're not linked!").setEphemeral(true).queue();
                    return;
                }
                boolean win = new Random().nextBoolean();
                if (win) {
                    CoinPlugin.coinManager.addCoins(uuid, 15);
                    PlayerStats.recordEarn(uuid, 15);
                    event.reply("🎉 You won the coinflip! +15 coins").setEphemeral(true).queue();
                } else {
                    CoinPlugin.coinManager.removeCoins(uuid, 10);
                    PlayerStats.recordLoss(uuid, 10);
                    event.reply("😢 You lost the coinflip! -10 coins").setEphemeral(true).queue();
                }
                break;

            case "stats":
                if (uuid == null) {
                    event.reply("You're not linked.").setEphemeral(true).queue();
                    return;
                }
                String msg = "📊 Your Stats:
" +
                        "• Coins Earned: " + PlayerStats.getCoinsEarned(uuid) + "
" +
                        "• Coins Lost: " + PlayerStats.getCoinsLost(uuid) + "
" +
                        "• Wins: " + PlayerStats.getWins(uuid) + "
" +
                        "• Losses: " + PlayerStats.getLosses(uuid);
                event.reply(msg).setEphemeral(true).queue();
                break;

            case "link":
                OptionMapping codeOpt = event.getOption("code");
                if (codeOpt == null) {
                    event.reply("⚠️ Please provide a valid 6-digit code from Minecraft.").setEphemeral(true).queue();
                    return;
                }
                String code = codeOpt.getAsString();
                try {
                    UUID mcUUID = CoinPlugin.linkManager.getMinecraftUUID(code);
                    if (mcUUID != null) {
                        CoinPlugin.linkManager.link(mcUUID, discordId);
                        event.reply("🔗 Linked successfully to your Minecraft account!").setEphemeral(true).queue();
                    } else {
                        event.reply("❌ Invalid or expired code.").setEphemeral(true).queue();
                    }
                } catch (Exception e) {
                    event.reply("❌ Linking failed.").setEphemeral(true).queue();
                }
                break;
        }
    }
}
