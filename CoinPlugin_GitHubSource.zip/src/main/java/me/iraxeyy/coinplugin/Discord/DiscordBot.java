
package me.iraxeyy.coinplugin.Discord;

import me.iraxeyy.coinplugin.CoinPlugin;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.entities.Activity;
import net.dv8tion.jda.api.entities.channel.concrete.TextChannel;
import net.dv8tion.jda.api.interactions.commands.build.Commands;

public class DiscordBot {

    public static void start() {
        try {
            String token = CoinPlugin.instance.getConfig().getString("discord-token");
            if (token == null || token.equalsIgnoreCase("changeme")) {
                CoinPlugin.instance.getLogger().warning("❌ Bot token missing in config.yml. Bot not starting.");
                return;
            }

            JDA jda = JDABuilder.createDefault(token)
                .setActivity(Activity.playing("💰 Coins | /daily"))
                .addEventListeners(new SlashHandler())
                .build();

            jda.updateCommands().addCommands(
                Commands.slash("daily", "Claim your daily 5 coins"),
                Commands.slash("trivia", "Play a trivia game for coins"),
                Commands.slash("coinflip", "Flip a coin to win or lose coins"),
                Commands.slash("stats", "View your coin stats"),
                Commands.slash("link", "Link your Discord to Minecraft")
                    .addOption(net.dv8tion.jda.api.interactions.commands.OptionType.STRING, "code", "6-digit code from Minecraft", true)
            ).queue();

            jda.awaitReady();
            String message = "✅ Bot is online and slash commands registered!";
            for (TextChannel channel : jda.getTextChannels()) {
                if (channel.getName().toLowerCase().contains("bot") || channel.getName().contains("coin")) {
                    channel.sendMessage(message).queue();
                    break;
                }
            }

        } catch (Exception e) {
            CoinPlugin.instance.getLogger().warning("⚠️ Failed to start Discord bot: " + e.getMessage());
        }
    }
}
