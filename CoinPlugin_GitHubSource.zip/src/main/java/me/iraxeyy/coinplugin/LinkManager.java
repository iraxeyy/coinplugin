// LinkManager.java
package me.iraxeyy.coinplugin;

import java.util.HashMap;
import java.util.UUID;

public class LinkManager {
    private final HashMap<String, UUID> discordToMc = new HashMap<>();
    private final HashMap<String, UUID> codeToMc = new HashMap<>();

    public void link(UUID uuid, String discordId) {
        discordToMc.put(discordId, uuid);
    }

    public UUID getMinecraftUUID(String discordId) {
        return discordToMc.get(discordId);
    }

    public UUID getMinecraftUUIDFromCode(String code) {
        return codeToMc.get(code);
    }

    public void storeCode(String code, UUID uuid) {
        codeToMc.put(code, uuid);
    }
}
