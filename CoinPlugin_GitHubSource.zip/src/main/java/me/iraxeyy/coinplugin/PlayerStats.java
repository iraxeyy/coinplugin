// PlayerStats.java
package me.iraxeyy.coinplugin;

import java.util.HashMap;
import java.util.UUID;

public class PlayerStats {
    private static final HashMap<UUID, Integer> earned = new HashMap<>();
    private static final HashMap<UUID, Integer> lost = new HashMap<>();
    private static final HashMap<UUID, Integer> wins = new HashMap<>();
    private static final HashMap<UUID, Integer> losses = new HashMap<>();

    public static void recordEarn(UUID uuid, int amount) {
        earned.put(uuid, earned.getOrDefault(uuid, 0) + amount);
    }

    public static void recordLoss(UUID uuid, int amount) {
        lost.put(uuid, lost.getOrDefault(uuid, 0) + amount);
    }

    public static void recordWin(UUID uuid) {
        wins.put(uuid, wins.getOrDefault(uuid, 0) + 1);
    }

    public static void recordLoss(UUID uuid) {
        losses.put(uuid, losses.getOrDefault(uuid, 0) + 1);
    }

    public static int getCoinsEarned(UUID uuid) {
        return earned.getOrDefault(uuid, 0);
    }

    public static int getCoinsLost(UUID uuid) {
        return lost.getOrDefault(uuid, 0);
    }

    public static int getWins(UUID uuid) {
        return wins.getOrDefault(uuid, 0);
    }

    public static int getLosses(UUID uuid) {
        return losses.getOrDefault(uuid, 0);
    }
}
