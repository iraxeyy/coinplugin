package me.iraxeyy.coinplugin;

import me.iraxeyy.coinplugin.Commands.CoinsCommand;
import me.iraxeyy.coinplugin.Commands.LeaderboardCommand;
import me.iraxeyy.coinplugin.Commands.LinkCommand;
import org.bukkit.plugin.java.JavaPlugin;

public class CoinPlugin extends JavaPlugin {
    public static CoinPlugin instance;
    public static CoinManager coinManager;
    public static LinkManager linkManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        coinManager = new CoinManager();
        linkManager = new LinkManager();

        getCommand("coins").setExecutor(new CoinsCommand());
        getCommand("leaderboard").setExecutor(new LeaderboardCommand());
        getCommand("link").setExecutor(new LinkCommand());

        getLogger().info("✅ CoinPlugin has been enabled!");
    }

    @Override
    public void onDisable() {
        getLogger().info("❌ CoinPlugin has been disabled.");
    }
}
