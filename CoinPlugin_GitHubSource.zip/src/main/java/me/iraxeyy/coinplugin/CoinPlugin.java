
package me.iraxeyy.coinplugin;

import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.EventHandler;

import me.iraxeyy.coinplugin.Commands.*;
import me.iraxeyy.coinplugin.Discord.DiscordBot;

public class CoinPlugin extends JavaPlugin {

    public static CoinPlugin instance;
    public static CoinManager coinManager;
    public static LinkManager linkManager;

    @Override
    public void onEnable() {
        instance = this;
        coinManager = new CoinManager();
        linkManager = new LinkManager();

        getCommand("coins").setExecutor(new CoinsCommand());
        getCommand("leaderboard").setExecutor(new LeaderboardCommand());
        getCommand("link").setExecutor(new LinkCommand());

        getServer().getPluginManager().registerEvents(new Listener() {
            @EventHandler
            public void onJoin(PlayerJoinEvent e) {
                PlayerScoreboard.show(e.getPlayer());
            }
        }, this);

        DiscordBot.start(); // Start the bot
        getLogger().info("🪙 Luxury CoinPlugin Enabled");
    }

    @Override
    public void onDisable() {
        getLogger().info("❌ CoinPlugin Disabled");
    }
}
