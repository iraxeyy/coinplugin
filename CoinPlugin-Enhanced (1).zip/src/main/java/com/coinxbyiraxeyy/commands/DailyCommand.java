package com.coinxbyiraxeyy.commands;
import org.bukkit.command.*; import com.coinxbyiraxeyy.managers.CoinManager;
public class DailyCommand implements CommandExecutor {
    public DailyCommand(CoinManager cm) {}
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) { return true; }
}