package com.coinxbyiraxeyy.managers;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.ChatColor;
import org.bukkit.plugin.java.JavaPlugin;

public class ShopManager {
    private final JavaPlugin plugin;
    private final EconomyManager economyManager;

    public ShopManager(JavaPlugin plugin, EconomyManager economyManager) {
        this.plugin = plugin;
        this.economyManager = economyManager;
    }

    public void listItems(Player player) {
        ConfigurationSection shop = plugin.getConfig().getConfigurationSection("shop-items");
        if (shop == null) {
            player.sendMessage(ChatColor.RED + "No shop items configured.");
            return;
        }

        for (String key : shop.getKeys(false)) {
            String name = shop.getString(key + ".name");
            int cost = shop.getInt(key + ".cost");
            player.sendMessage(ChatColor.AQUA + "- " + name + " for " + cost + " coins (/shop " + key + ")");
        }
    }

    public void purchaseItem(Player player, String itemId) {
        ConfigurationSection item = plugin.getConfig().getConfigurationSection("shop-items." + itemId);
        if (item == null) {
            player.sendMessage(ChatColor.RED + "Item not found.");
            return;
        }

        String name = item.getString("name");
        int cost = item.getInt("cost");
        if (economyManager.getCoins(player.getUniqueId()) < cost) {
            player.sendMessage(ChatColor.RED + "Not enough coins.");
            return;
        }

        economyManager.removeCoins(player.getUniqueId(), cost);
        player.sendMessage(ChatColor.GREEN + "You purchased " + name + " for " + cost + " coins!");
        // You can implement giving items/ranks here
    }
}