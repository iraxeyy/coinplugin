
package me.iraxeyy.coinplugin;

import java.util.HashMap;
import java.util.UUID;

public class PlayerStats {

    private static final HashMap<UUID, Integer> coinsEarned = new HashMap<>();
    private static final HashMap<UUID, Integer> coinLosses = new HashMap<>();
    private static final HashMap<UUID, Integer> wins = new HashMap<>();
    private static final HashMap<UUID, Integer> losses = new HashMap<>();

    public static void recordEarn(UUID uuid, int amount) {
        coinsEarned.put(uuid, coinsEarned.getOrDefault(uuid, 0) + amount);
        wins.put(uuid, wins.getOrDefault(uuid, 0) + 1);
    }

    public static void recordLoss(UUID uuid, int amount) {
        coinLosses.put(uuid, coinLosses.getOrDefault(uuid, 0) + amount);
        losses.put(uuid, losses.getOrDefault(uuid, 0) + 1);
    }

    public static int getCoinsEarned(UUID uuid) {
        return coinsEarned.getOrDefault(uuid, 0);
    }

    public static int getCoinsLost(UUID uuid) {
        return coinLosses.getOrDefault(uuid, 0);
    }

    public static int getWins(UUID uuid) {
        return wins.getOrDefault(uuid, 0);
    }

    public static int getLosses(UUID uuid) {
        return losses.getOrDefault(uuid, 0);
    }
}
