
package me.iraxeyy.coinplugin.Discord;

import me.iraxeyy.coinplugin.CoinPlugin;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.entities.Activity;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

public class DiscordBot {

    public static void start() {
        try {
            String token = CoinPlugin.instance.getConfig().getString("discord-token");
            if (token == null || token.equalsIgnoreCase("changeme")) {
                CoinPlugin.instance.getLogger().warning("❌ Bot token missing in config.yml. Bot not starting.");
                return;
            }

            JDABuilder.createDefault(token)
                .setActivity(Activity.playing("💰 Coins | /daily"))
                .addEventListeners(new SlashHandler())
                .build();

        } catch (Exception e) {
            CoinPlugin.instance.getLogger().warning("⚠️ Failed to start Discord bot: " + e.getMessage());
        }
    }
}
