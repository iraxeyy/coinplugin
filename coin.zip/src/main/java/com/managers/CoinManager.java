package com.yourplugin.managers;

import org.bukkit.plugin.java.JavaPlugin;
import java.util.UUID;

public class CoinManager {
    private final JavaPlugin plugin;
    private final DatabaseManager database;

    public CoinManager(JavaPlugin plugin, DatabaseManager database) {
        this.plugin = plugin;
        this.database = database;
    }

    public int getCoins(UUID player) {
        return database.getCoins(player);
    }

    public void addCoins(UUID player, int amount) {
        database.addCoins(player, amount);
    }

    public boolean removeCoins(UUID player, int amount) {
        int current = getCoins(player);
        if (current >= amount) {
            database.setCoins(player, current - amount);
            return true;
        }
        return false;
    }

    public void giveDailyReward(UUID player) {
        addCoins(player, plugin.getConfig().getInt("economy.daily-reward"));
    }
}