package com.yourplugin;

import com.yourplugin.commands.*;
import com.yourplugin.discord.DiscordBot;
import com.yourplugin.listeners.*;
import com.yourplugin.managers.*;
import org.bukkit.plugin.java.JavaPlugin;

public class Main extends JavaPlugin {
    private CoinManager coinManager;
    private DatabaseManager databaseManager;
    private DiscordBot discordBot;

    @Override
    public void onEnable() {
        // Save default config if doesn't exist
        saveDefaultConfig();
        
        // Initialize managers
        this.databaseManager = new DatabaseManager(this);
        this.coinManager = new CoinManager(this, databaseManager);
        
        // Register commands
        getCommand("balance").setExecutor(new BalanceCommand(coinManager));
        getCommand("daily").setExecutor(new DailyCommand(coinManager));
        getCommand("shop").setExecutor(new ShopCommand(new ShopManager(this, coinManager)));
        getCommand("discordlink").setExecutor(new DiscordLinkCommand(discordBot));
        
        // Register events
        getServer().getPluginManager().registerEvents(new JoinListener(
            new LeaderboardManager(this, coinManager)), this);
        getServer().getPluginManager().registerEvents(new ChatListener(coinManager), this);
        
        // Start Discord bot
        try {
            this.discordBot = new DiscordBot(this, coinManager);
            discordBot.startBot(getConfig().getString("discord.token"));
        } catch (Exception e) {
            getLogger().severe("Failed to start Discord bot: " + e.getMessage());
        }
        
        getLogger().info("Plugin enabled!");
    }

    @Override
    public void onDisable() {
        if (discordBot != null) {
            discordBot.shutdown();
        }
        databaseManager.closeConnection();
        getLogger().info("Plugin disabled!");
    }
}