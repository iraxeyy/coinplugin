package com.yourplugin.listeners;

import com.yourplugin.managers.CoinManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

public class ChatListener implements Listener {
    private final CoinManager coinManager;

    public ChatListener(CoinManager coinManager) {
        this.coinManager = coinManager;
    }

    @EventHandler
    public void onChat(AsyncPlayerChatEvent event) {
        coinManager.addCoins(event.getPlayer().getUniqueId(), 
            coinManager.getPlugin().getConfig().getInt("economy.chat-reward"));
    }
}