package com.yourplugin.discord;

import com.yourplugin.managers.CoinManager;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.entities.*;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import org.bukkit.plugin.java.JavaPlugin;
import javax.security.auth.login.LoginException;
import java.util.*;

public class DiscordBot extends ListenerAdapter {
    private JDA jda;
    private final JavaPlugin plugin;
    private final CoinManager coinManager;
    private final Map<String, UUID> pendingLinks = new HashMap<>();

    public DiscordBot(JavaPlugin plugin, CoinManager coinManager) {
        this.plugin = plugin;
        this.coinManager = coinManager;
    }

    public void startBot(String token) throws LoginException {
        jda = JDABuilder.createDefault(token)
            .addEventListeners(this)
            .build();
    }

    public void shutdown() {
        if (jda != null) jda.shutdown();
    }

    @Override
    public void onMessageReceived(MessageReceivedEvent event) {
        if (event.getAuthor().isBot()) return;

        String content = event.getMessage().getContentRaw();
        User user = event.getAuthor();
        MessageChannel channel = event.getChannel();

        if (content.startsWith("/link ")) {
            handleLink(user, content.substring(6).trim(), channel);
        } else if (content.equalsIgnoreCase("/daily")) {
            handleDaily(user, channel);
        }
    }

    private void handleLink(User user, String code, MessageChannel channel) {
        UUID uuid = pendingLinks.get(code);
        if (uuid != null) {
            pendingLinks.remove(code);
            plugin.getServer().getScheduler().runTask(plugin, () -> {
                database.linkDiscordAccount(uuid, user.getId());
                channel.sendMessage("✅ Account linked successfully!").queue();
            });
        } else {
            channel.sendMessage("❌ Invalid link code!").queue();
        }
    }

    private void handleDaily(User user, MessageChannel channel) {
        String discordId = user.getId();
        UUID uuid = database.getPlayerFromDiscord(discordId);
        
        if (uuid != null) {
            plugin.getServer().getScheduler().runTask(plugin, () -> {
                coinManager.giveDailyReward(uuid);
                channel.sendMessage("🎉 You received your daily " + 
                    plugin.getConfig().getInt("economy.daily-reward") + 
                    " coins!").queue();
            });
        } else {
            channel.sendMessage("❌ No Minecraft account linked!").queue();
        }
    }

    public String generateLinkCode(UUID uuid) {
        String code = UUID.randomUUID().toString().substring(0, 6);
        pendingLinks.put(code, uuid);
        return code;
    }
}