package com.yourplugin.commands;

import com.yourplugin.managers.CoinManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class BalanceCommand implements CommandExecutor {
    private final CoinManager coinManager;

    public BalanceCommand(CoinManager coinManager) {
        this.coinManager = coinManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Only players can use this command!");
            return true;
        }

        Player player = (Player) sender;
        int coins = coinManager.getCoins(player.getUniqueId());
        player.sendMessage("§aYour balance: §e" + coins + " coins");
        return true;
    }
}