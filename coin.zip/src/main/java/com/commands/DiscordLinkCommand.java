package com.yourplugin.commands;

import com.yourplugin.Main;
import com.yourplugin.discord.DiscordBot;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import java.util.UUID;

public class DiscordLinkCommand implements CommandExecutor {
    private final Main plugin;

    public DiscordLinkCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§cOnly players can use this command!");
            return true;
        }

        Player player = (Player) sender;
        UUID uuid = player.getUniqueId();

        String code = plugin.getDiscordBot().generateLinkCode(uuid);
        player.sendMessage(new String[] {
            "§6§lDiscord Account Linking",
            "§7To link your account:",
            "",
            "1. Join our Discord server",
            "2. Type this command in any channel:",
            "§a/link " + code,
            "",
            "§cThis code expires in 10 minutes!"
        });

        return true;
    }
}