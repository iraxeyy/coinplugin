package com.coinxbyiraxeyy.listeners;
import org.bukkit.event.Listener;
public class ChatListener implements Listener {
    public ChatListener() {}
}