package com.coinxbyiraxeyy.listeners;

import com.coinxbyiraxeyy.managers.LeaderboardManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public class JoinListener implements Listener {
    private final LeaderboardManager leaderboardManager;

    public JoinListener(LeaderboardManager leaderboardManager) {
        this.leaderboardManager = leaderboardManager;
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        leaderboardManager.updateScoreboard(player);
    }
}