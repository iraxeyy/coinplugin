package com.coinxbyiraxeyy.listeners;
import org.bukkit.event.Listener;
public class JoinListener implements Listener {
    public JoinListener() {}
}