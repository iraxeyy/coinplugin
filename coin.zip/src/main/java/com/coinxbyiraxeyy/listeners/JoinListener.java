
import org.bukkit.Bukkit;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.scoreboard.*;

public class JoinListener implements Listener {
    private final CoinManager coinManager;
    private final DatabaseManager database;

    public JoinListener(CoinManager coinManager, DatabaseManager database) {
        this.coinManager = coinManager;
        this.database = database;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        int coins = coinManager.getCoins(uuid);
        String discord = database.getDiscordFromUUID(uuid);
        if (discord == null) discord = "Not linked";

        ScoreboardManager manager = Bukkit.getScoreboardManager();
        Scoreboard board = manager.getNewScoreboard();
        Objective obj = board.registerNewObjective("coinboard", "dummy", ChatColor.GOLD + "Your Stats");
        obj.setDisplaySlot(DisplaySlot.SIDEBAR);

        Score name = obj.getScore(ChatColor.YELLOW + "Name: " + ChatColor.WHITE + player.getName());
        Score balance = obj.getScore(ChatColor.YELLOW + "Coins: " + ChatColor.WHITE + coins);
        Score link = obj.getScore(ChatColor.YELLOW + "Discord: " + ChatColor.WHITE + discord);

        name.setScore(3);
        balance.setScore(2);
        link.setScore(1);

        player.setScoreboard(board);
    }
}
