package com.coinxbyiraxeyy;

import com.coinxbyiraxeyy.commands.*;
import com.coinxbyiraxeyy.discord.DiscordBot;
import com.coinxbyiraxeyy.listeners.*;
import com.coinxbyiraxeyy.managers.*;
import org.bukkit.plugin.java.JavaPlugin;

public class Main extends JavaPlugin {
    // Manager instances
    private CoinManager coinManager;
    private DatabaseManager databaseManager;
    private ShopManager shopManager;
    private LeaderboardManager leaderboardManager;
    private DiscordBot discordBot;

    @Override
    public void onEnable() {
        // Save default configuration if it doesn't exist
        saveDefaultConfig();
        
        // Initialize all managers
        initializeManagers();

        // Register all commands
        registerCommands();

        // Register all event listeners
        registerEventListeners();

        // Start the Discord bot
        startDiscordBot();

        getLogger().info("CoinX plugin has been successfully enabled!");
    }

    @Override
    public void onDisable() {
        // Shutdown Discord bot if running
        if (discordBot != null) {
            discordBot.shutdown();
            getLogger().info("Discord bot has been shutdown.");
        }
        
        // Close database connection
        databaseManager.closeConnection();
        getLogger().info("Database connection closed.");
        
        getLogger().info("CoinX plugin has been disabled!");
    }

    private void initializeManagers() {
        this.databaseManager = new DatabaseManager(this);
        this.coinManager = new CoinManager(this, databaseManager);
        this.shopManager = new ShopManager(this, coinManager);
        this.leaderboardManager = new LeaderboardManager(this, coinManager);
    }

    private void registerCommands() {
        getCommand("balance").setExecutor(new BalanceCommand(coinManager));
        getCommand("daily").setExecutor(new DailyCommand(coinManager));
        getCommand("shop").setExecutor(new ShopCommand(shopManager));
        getCommand("discordlink").setExecutor(new DiscordLinkCommand(this));
        
        getLogger().info("All commands registered successfully.");
    }

    private void registerEventListeners() {
        getServer().getPluginManager().registerEvents(new JoinListener(leaderboardManager), this);
        getServer().getPluginManager().registerEvents(new ChatListener(coinManager), this);
        getServer().getPluginManager().registerEvents(new ShopListener(shopManager), this);
        
        getLogger().info("All event listeners registered successfully.");
    }

    private void startDiscordBot() {
        try {
            String botToken = getConfig().getString("discord.token");
            
            if (botToken == null || botToken.isEmpty()) {
                getLogger().severe("No Discord bot token found in config.yml!");
                return;
            }
            
            this.discordBot = new DiscordBot(this, coinManager, databaseManager);
            discordBot.startBot(botToken);
            getLogger().info("Discord bot started successfully!");
        } catch (Exception e) {
            getLogger().severe("Failed to start Discord bot: " + e.getMessage());
        }
    }

    // Getter for DiscordBot instance
    public DiscordBot getDiscordBot() {
        return discordBot;
    }

    // Getter for CoinManager instance
    public CoinManager getCoinManager() {
        return coinManager;
    }
}