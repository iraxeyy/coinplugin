package com.coinxbyiraxeyy;

import com.coinxbyiraxeyy.commands.*;
import com.coinxbyiraxeyy.discord.DiscordBot;
import com.coinxbyiraxeyy.listeners.*;
import com.coinxbyiraxeyy.managers.*;
import org.bukkit.plugin.java.JavaPlugin;

public class Main extends JavaPlugin {
    // Manager instances
    private CoinManager coinManager;
    private DatabaseManager databaseManager;
    private ShopManager shopManager;
    private LeaderboardManager leaderboardManager;
    private DiscordBot discordBot;

    @Override
    public void onEnable() {
        // Save default configuration
        saveDefaultConfig();
        
        // Initialize managers
        this.databaseManager = new DatabaseManager(this);
        this.coinManager = new CoinManager(this, databaseManager);
        this.shopManager = new ShopManager(this, coinManager);
        this.leaderboardManager = new LeaderboardManager(this, coinManager);

        // Register commands
        registerCommands();

        // Register event listeners
        registerEvents();

        // Start Discord bot
        startDiscordBot();

        getLogger().info("CoinX plugin has been enabled!");
    }

    @Override
    public void onDisable() {
        // Shutdown Discord bot
        if (discordBot != null) {
            discordBot.shutdown();
        }
        
        // Close database connection
        databaseManager.closeConnection();
        
        getLogger().info("CoinX plugin has been disabled!");
    }

    private void registerCommands() {
        getCommand("balance").setExecutor(new BalanceCommand(coinManager));
        getCommand("daily").setExecutor(new DailyCommand(coinManager));
        getCommand("shop").setExecutor(new ShopCommand(shopManager));
        getCommand("discordlink").setExecutor(new DiscordLinkCommand(this));
    }

    private void registerEvents() {
        getServer().getPluginManager().registerEvents(new JoinListener(leaderboardManager), this);
        getServer().getPluginManager().registerEvents(new ChatListener(coinManager), this);
        getServer().getPluginManager().registerEvents(new ShopListener(shopManager), this);
    }

    private void startDiscordBot() {
        try {
            this.discordBot = new DiscordBot(this, coinManager, databaseManager);
            String botToken = getConfig().getString("discord.token");
            if (botToken == null || botToken.isEmpty()) {
                getLogger().severe("No Discord bot token found in config.yml!");
                return;
            }
            discordBot.startBot(botToken);
        } catch (Exception e) {
            getLogger().severe("Failed to start Discord bot: " + e.getMessage());
        }
    }

    public DiscordBot getDiscordBot() {
        return discordBot;
    }

    public CoinManager getCoinManager() {
        return coinManager;
    }
}