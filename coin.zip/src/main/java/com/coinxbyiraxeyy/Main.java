package com.coinxbyiraxeyy;

import com.coinxbyiraxeyy.commands.*;
import com.coinxbyiraxeyy.discord.DiscordBot;
import com.coinxbyiraxeyy.listeners.*;
import com.coinxbyiraxeyy.managers.*;
import org.bukkit.plugin.java.JavaPlugin;

public class Main extends JavaPlugin {
    private CoinManager coinManager;
    private DatabaseManager databaseManager;
    private ShopManager shopManager;
    private LeaderboardManager leaderboardManager;
    private DiscordBot discordBot;

    @Override
    public void onEnable() {
        // Save default config
        saveDefaultConfig();
        
        // Initialize managers
        this.databaseManager = new DatabaseManager(this);
        this.coinManager = new CoinManager(this, databaseManager);
        this.shopManager = new ShopManager(this, coinManager);
        this.leaderboardManager = new LeaderboardManager(this, coinManager);

        // Register commands
        getCommand("balance").setExecutor(new BalanceCommand(coinManager));
        getCommand("daily").setExecutor(new DailyCommand(coinManager));
        getCommand("shop").setExecutor(new ShopCommand(shopManager));
        getCommand("discordlink").setExecutor(new DiscordLinkCommand(this));

        // Register event listeners
        getServer().getPluginManager().registerEvents(new JoinListener(leaderboardManager), this);
        getServer().getPluginManager().registerEvents(new ChatListener(coinManager), this);
        getServer().getPluginManager().registerEvents(new ShopListener(shopManager), this);

        // Start Discord bot
        try {
            this.discordBot = new DiscordBot(this, coinManager, databaseManager);
            discordBot.startBot(getConfig().getString("discord.token"));
        } catch (Exception e) {
            getLogger().severe("Failed to start Discord bot: " + e.getMessage());
        }

        getLogger().info("CoinX plugin has been enabled!");
    }

    @Override
    public void onDisable() {
        // Shutdown Discord bot
        if (discordBot != null) {
            discordBot.shutdown();
        }
        
        // Close database connection
        databaseManager.closeConnection();
        
        getLogger().info("CoinX plugin has been disabled!");
    }

    public DiscordBot getDiscordBot() {
        return discordBot;
    }
}