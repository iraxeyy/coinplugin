package com.coinxbyiraxeyy;

import com.coinxbyiraxeyy.commands.*;
import com.coinxbyiraxeyy.discord.DiscordBot;
import com.coinxbyiraxeyy.listeners.*;
import com.coinxbyiraxeyy.managers.*;
import org.bukkit.plugin.java.JavaPlugin;

public class Main extends JavaPlugin {
    private CoinManager coinManager;
    private DatabaseManager databaseManager;
    private ShopManager shopManager;
    private LeaderboardManager leaderboardManager;
    private DiscordBot discordBot;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        
        this.databaseManager = new DatabaseManager(this);
        this.coinManager = new CoinManager(this, databaseManager);
        this.shopManager = new ShopManager(this, coinManager);
        this.leaderboardManager = new LeaderboardManager(this, coinManager);

        getCommand("balance").setExecutor(new BalanceCommand(coinManager));
        getCommand("daily").setExecutor(new DailyCommand(coinManager));
        getCommand("shop").setExecutor(new ShopCommand(shopManager));
        getCommand("discordlink").setExecutor(new DiscordLinkCommand(this));

        getServer().getPluginManager().registerEvents(new JoinListener(leaderboardManager), this);
        getServer().getPluginManager().registerEvents(new ChatListener(coinManager), this);
        getServer().getPluginManager().registerEvents(new ShopListener(shopManager), this);

        try {
            this.discordBot = new DiscordBot(this, coinManager, databaseManager);
            String token = getConfig().getString("discord.token");
            if (token == null || token.isEmpty()) {
                getLogger().severe("No Discord token found in config.yml!");
            } else {
                discordBot.startBot(token);
            }
        } catch (Exception e) {
            getLogger().severe("Failed to start Discord bot: " + e.getMessage());
        }
    }

    @Override
    public void onDisable() {
        if (discordBot != null) {
            discordBot.shutdown();
        }
        databaseManager.closeConnection();
    }

    public DiscordBot getDiscordBot() {
        return discordBot;
    }

    public CoinManager getCoinManager() {
        return coinManager;
    }
}