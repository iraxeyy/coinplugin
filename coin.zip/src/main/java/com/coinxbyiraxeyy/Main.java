package com.coinxbyiraxeyy;

import org.bukkit.plugin.java.JavaPlugin;
import com.coinxbyiraxeyy.managers.*;
import com.coinxbyiraxeyy.listeners.*;

public class Main extends JavaPlugin {

    private DiscordBot discordBot;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        // Initialize managers
        CoinManager coinManager = new CoinManager(this);
        DatabaseManager databaseManager = new DatabaseManager(this);
        GameManager gameManager = new GameManager(this, coinManager);
        ShopManager shopManager = new ShopManager(this);

        // Register Minecraft commands
        new BetCommand(this, gameManager);
        new HorseRaceCommand(this, gameManager);
        new ShopCommand(this, shopManager);
        new BalanceCommand(this, coinManager);
        new DiscordLinkCommand(this, coinManager, databaseManager);

        // Start Discord Bot
        String token = getConfig().getString("discord.token");
        if (token != null && !token.isEmpty()) {
            try {
                discordBot = new DiscordBot(this, coinManager, databaseManager);
                discordBot.startBot(token);
                getLogger().info("✅ Discord bot started!");
            } catch (Exception e) {
                getLogger().warning("❌ Failed to start Discord bot: " + e.getMessage());
            }
        } else {
            getLogger().warning("❌ Discord bot token not found in config.yml");
        }

        // Register events
        getServer().getPluginManager().registerEvents(new JoinListener(coinManager, databaseManager), this);
        getServer().getPluginManager().registerEvents(new ChatListener(databaseManager), this);
        getServer().getPluginManager().registerEvents(new ShopListener(shopManager), this);
    }

    @Override
    public void onDisable() {
        if (discordBot != null) {
            discordBot.shutdown();
        }
    }

    private static Main instance;
    private DatabaseManager databaseManager;
    private EconomyManager economyManager;
    private GameManager gameManager;
    
    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        
        // Initialize managers
        this.databaseManager = new DatabaseManager();
        this.economyManager = new EconomyManager(databaseManager);
        this.gameManager = new GameManager(economyManager);
        
        // Register commands
        new BalanceCommand(this);
        new DailyCommand(this);
        new SpinCommand(this, gameManager);
        new BetCommand(this, gameManager);
        new HorseRaceCommand(this, gameManager);
        
        // Register listeners
        getServer().getPluginManager().registerEvents(new JoinListener(economyManager), this);
        getServer().getPluginManager().registerEvents(new ChatListener(), this);
        
        getLogger().info("Plugin enabled successfully!");
    }
    
    public static Main getInstance() {
        return instance;
    }
    
    public DatabaseManager getDatabaseManager() {
        return databaseManager;
    }
}