package com.coinxbyiraxeyy.discord;

import com.coinxbyiraxeyy.managers.CoinManager;
import com.coinxbyiraxeyy.managers.DatabaseManager;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import net.dv8tion.jda.api.interactions.commands.build.Commands;
import net.dv8tion.jda.api.entities.User;
import org.bukkit.plugin.java.JavaPlugin;

import javax.security.auth.login.LoginException;
import java.util.*;

public class DiscordBot extends ListenerAdapter {
    private JDA jda;
    private final JavaPlugin plugin;
    private final CoinManager coinManager;
    private final DatabaseManager database;
    private final Map<String, UUID> pendingLinks = new HashMap<>();
    private final Map<String, String> triviaAnswers = new HashMap<>();

    public DiscordBot(JavaPlugin plugin, CoinManager coinManager, DatabaseManager database) {
        this.plugin = plugin;
        this.coinManager = coinManager;
        this.database = database;
    }

    public void startBot(String token) throws LoginException {
        jda = JDABuilder.createDefault(token)
                .addEventListeners(this)
                .build();

        jda.updateCommands().addCommands(
            Commands.slash("link", "Link your Minecraft account").addOption(
                net.dv8tion.jda.api.interactions.commands.OptionType.STRING, "code", "Enter the 6-digit code from Minecraft", true
            ),
            Commands.slash("daily", "Claim your daily reward"),
            Commands.slash("balance", "Check your coin balance"),
            Commands.slash("coinflip", "Flip a coin to win or lose coins").addOption(
                net.dv8tion.jda.api.interactions.commands.OptionType.INTEGER, "amount", "Coins to bet", true
            ),
            Commands.slash("stats", "View your coin stats"),
            Commands.slash("trivia", "Answer a trivia question for coins"),
            Commands.slash("bet", "Bet on a number 1-100 to win coins")
                .addOption(net.dv8tion.jda.api.interactions.commands.OptionType.INTEGER, "amount", "Coins to bet", true)
                .addOption(net.dv8tion.jda.api.interactions.commands.OptionType.INTEGER, "number", "Your number (1-100)", true),
            Commands.slash("horserace", "Bet on a horse to win")
                .addOption(net.dv8tion.jda.api.interactions.commands.OptionType.INTEGER, "amount", "Coins to bet", true)
                .addOption(net.dv8tion.jda.api.interactions.commands.OptionType.INTEGER, "horse", "Pick a horse (1-5)", true)
        ).queue();
    }

    public void shutdown() {
        if (jda != null) jda.shutdown();
    }

    @Override
    public void onSlashCommandInteraction(SlashCommandInteractionEvent event) {
        User user = event.getUser();
        String cmd = event.getName();

        switch (cmd) {
            case "link":
                handleLink(user, event.getOption("code").getAsString(), event);
                break;
            case "daily":
                handleDaily(user, event);
                break;
            case "balance":
                handleBalance(user, event);
                break;
            case "coinflip":
                handleCoinFlip(user, event.getOption("amount").getAsInt(), event);
                break;
            case "stats":
                handleStats(user, event);
                break;
            case "trivia":
                handleTrivia(user, event);
                break;
        }
    }

    private void handleLink(User user, String code, SlashCommandInteractionEvent event) {
        UUID uuid = pendingLinks.get(code);
        if (uuid != null) {
            pendingLinks.remove(code);
            database.linkDiscordAccount(uuid, user.getId());
            event.reply("✅ Account linked successfully!").queue();
        } else {
            event.reply("❌ Invalid link code!").setEphemeral(true).queue();
        }
    }

    private void handleDaily(User user, SlashCommandInteractionEvent event) {
        UUID uuid = database.getPlayerFromDiscord(user.getId());
        if (uuid != null) {
            if (coinManager.canClaimDaily(uuid)) {
                coinManager.giveDailyReward(uuid);
                event.reply("🎉 You received your daily coins!").queue();
            } else {
                event.reply("⏳ You've already claimed your daily reward today!").setEphemeral(true).queue();
            }
        } else {
            event.reply("❌ No Minecraft account linked! Use `/link` first.").setEphemeral(true).queue();
        }
    }

    private void handleBalance(User user, SlashCommandInteractionEvent event) {
        UUID uuid = database.getPlayerFromDiscord(user.getId());
        if (uuid != null) {
            int coins = coinManager.getCoins(uuid);
            event.reply("💰 You have " + coins + " coins.").queue();
        } else {
            event.reply("❌ No linked Minecraft account. Use `/link`.").setEphemeral(true).queue();
        }
    }

    private void handleCoinFlip(User user, int amount, SlashCommandInteractionEvent event) {
        UUID uuid = database.getPlayerFromDiscord(user.getId());
        if (uuid != null) {
            if (coinManager.getCoins(uuid) < amount || amount <= 0) {
                event.reply("❌ Not enough coins or invalid amount.").setEphemeral(true).queue();
                return;
            }
            boolean win = new Random().nextBoolean();
            if (win) {
                coinManager.addCoins(uuid, amount);
                event.reply("🎉 You won the coinflip and gained " + amount + " coins!").queue();
            } else {
                coinManager.removeCoins(uuid, amount);
                event.reply("💀 You lost the coinflip and lost " + amount + " coins.").queue();
            }
        } else {
            event.reply("❌ No linked Minecraft account. Use `/link`.").setEphemeral(true).queue();
        }
    }

    private void handleStats(User user, SlashCommandInteractionEvent event) {
        UUID uuid = database.getPlayerFromDiscord(user.getId());
        if (uuid != null) {
            int coins = coinManager.getCoins(uuid);
            boolean claimed = !coinManager.canClaimDaily(uuid);
            String stats = "💰 Coins: " + coins + "\n📅 Daily Claimed: " + (claimed ? "✅" : "❌");
            event.reply(stats).queue();
        } else {
            event.reply("❌ No linked Minecraft account. Use `/link`.").setEphemeral(true).queue();
        }
    }

    private void handleTrivia(User user, SlashCommandInteractionEvent event) {
        UUID uuid = database.getPlayerFromDiscord(user.getId());
        if (uuid != null) {
            String question = "What is the capital of France?\nA) Berlin\nB) Madrid\nC) Paris\nD) Rome";
            triviaAnswers.put(user.getId(), "C");
            event.reply("🧠 Trivia Time!
" + question + "
Reply with A, B, C, or D as your next message.").queue();
        } else {
            event.reply("❌ No linked Minecraft account. Use `/link`.").setEphemeral(true).queue();
        }
    }

    public String generateLinkCode(UUID uuid) {
        String code = UUID.randomUUID().toString().substring(0, 6);
        pendingLinks.put(code, uuid);
        new Timer().schedule(new TimerTask() {
            @Override
            public void run() {
                pendingLinks.remove(code);
            }
        }, 10 * 60 * 1000);
        return code;
    }
}

    private void handleBet(User user, int amount, int number, SlashCommandInteractionEvent event) {
        UUID uuid = database.getPlayerFromDiscord(user.getId());
        if (uuid != null) {
            if (number < 1 || number > 100 || amount <= 0 || coinManager.getCoins(uuid) < amount) {
                event.reply("❌ Invalid bet or not enough coins.").setEphemeral(true).queue();
                return;
            }
            int rolled = new Random().nextInt(100) + 1;
            if (rolled == number) {
                int reward = amount * 10;
                coinManager.addCoins(uuid, reward);
                event.reply("🎉 Exact match! You won " + reward + " coins! (rolled: " + rolled + ")").queue();
            } else {
                coinManager.removeCoins(uuid, amount);
                event.reply("💀 You lost the bet. (rolled: " + rolled + ")").queue();
            }
        } else {
            event.reply("❌ You need to `/link` your Minecraft account first.").setEphemeral(true).queue();
        }
    }

    private void handleHorseRace(User user, int amount, int horse, SlashCommandInteractionEvent event) {
        UUID uuid = database.getPlayerFromDiscord(user.getId());
        if (uuid != null) {
            if (horse < 1 || horse > 5 || amount <= 0 || coinManager.getCoins(uuid) < amount) {
                event.reply("❌ Invalid horse or not enough coins.").setEphemeral(true).queue();
                return;
            }
            int winningHorse = new Random().nextInt(5) + 1;
            if (winningHorse == horse) {
                int reward = amount * 5;
                coinManager.addCoins(uuid, reward);
                event.reply("🏇 Horse " + horse + " won! You earned " + reward + " coins!").queue();
            } else {
                coinManager.removeCoins(uuid, amount);
                event.reply("🐴 Your horse lost. Winning horse was " + winningHorse + ". You lost " + amount + " coins.").queue();
            }
        } else {
            event.reply("❌ You need to `/link` your Minecraft account first.").setEphemeral(true).queue();
        }
    }


    @Override
    public void onMessageReceived(net.dv8tion.jda.api.events.message.MessageReceivedEvent event) {
        if (event.getAuthor().isBot()) return;

        String userId = event.getAuthor().getId();
        String content = event.getMessage().getContentRaw().trim().toUpperCase();

        if (triviaAnswers.containsKey(userId)) {
            String correct = triviaAnswers.remove(userId);
            UUID uuid = database.getPlayerFromDiscord(userId);
            if (uuid == null) {
                event.getChannel().sendMessage("❌ You are not linked to a Minecraft account. Use `/link`.").queue();
                return;
            }
            if (content.equals(correct)) {
                coinManager.addCoins(uuid, 50);
                event.getChannel().sendMessage("✅ Correct! You earned 50 coins.").queue();
            } else {
                event.getChannel().sendMessage("❌ Incorrect. The correct answer was: " + correct).queue();
            }
        }
    }

}