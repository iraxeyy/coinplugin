package com.coinxbyiraxeyy.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import com.coinxbyiraxeyy.managers.GameManager;
import org.bukkit.ChatColor;
import com.coinxbyiraxeyy.Main; // ✅ This is what was missing!

public class BetCommand implements CommandExecutor {
    private final GameManager gameManager;

    public BetCommand(Main plugin, GameManager gameManager) {
        this.gameManager = gameManager;
        plugin.getCommand("bet").setExecutor(this);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Only players can use this command!");
            return true;
        }

        Player player = (Player) sender;

        if (args.length < 2) {
            player.sendMessage(ChatColor.RED + "Usage: /bet <amount> <number 1-100>");
            return true;
        }

        try {
            int amount = Integer.parseInt(args[0]);
            int number = Integer.parseInt(args[1]);

            if (amount <= 0) {
                player.sendMessage(ChatColor.RED + "Bet amount must be positive!");
                return true;
            }

            if (number < 1 || number > 100) {
                player.sendMessage(ChatColor.RED + "Number must be between 1-100!");
                return true;
            }

            gameManager.placeBet(player, amount, number);
        } catch (NumberFormatException e) {
            player.sendMessage(ChatColor.RED + "Invalid number format!");
        }

        return true;
    }
}
