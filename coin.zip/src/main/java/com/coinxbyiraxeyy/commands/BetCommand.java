package com.coinxbyiraxeyy.commands;
import org.bukkit.command.*; import org.bukkit.entity.Player; import com.coinxbyiraxeyy.managers.GameManager;
public class BetCommand implements CommandExecutor {
    public BetCommand(GameManager gm) {}
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) { return true; }
}