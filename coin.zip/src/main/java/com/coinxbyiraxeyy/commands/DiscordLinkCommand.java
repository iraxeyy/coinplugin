package com.coinxbyiraxeyy.commands;
import org.bukkit.command.*; import com.coinxbyiraxeyy.discord.DiscordBot;
public class DiscordLinkCommand implements CommandExecutor {
    public DiscordLinkCommand(DiscordBot bot) {}
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) { return true; }
}