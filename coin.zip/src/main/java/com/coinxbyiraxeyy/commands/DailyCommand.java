package com.yourplugin.commands;

import com.yourplugin.managers.CoinManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import java.util.UUID;

public class DailyCommand implements CommandExecutor {
    private final CoinManager coinManager;

    public DailyCommand(CoinManager coinManager) {
        this.coinManager = coinManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§cOnly players can use this command!");
            return true;
        }

        Player player = (Player) sender;
        UUID playerId = player.getUniqueId();

        if (coinManager.canClaimDaily(playerId)) {
            coinManager.giveDailyReward(playerId);
            player.sendMessage("§aYou claimed your daily reward!");
        } else {
            long cooldown = coinManager.getDailyCooldown(playerId);
            player.sendMessage(String.format("§cYou can claim again in %d hours %d minutes",
                cooldown / 3600,
                (cooldown % 3600) / 60));
        }
        return true;
    }
}