package com.coinxbyiraxeyy.commands;

import com.coinxbyiraxeyy.managers.CoinManager;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import java.util.UUID;

public class DailyCommand implements CommandExecutor {
    private final CoinManager coinManager;

    public DailyCommand(CoinManager coinManager) {
        this.coinManager = coinManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Only players can use this command!");
            return true;
        }

        Player player = (Player) sender;
        UUID playerId = player.getUniqueId();

        if (coinManager.canClaimDaily(playerId)) {
            coinManager.giveDailyReward(playerId);
            int reward = coinManager.getPlugin().getConfig().getInt("economy.daily-reward", 50);
            player.sendMessage(ChatColor.GREEN + "You claimed your daily reward of " + reward + " coins!");
        } else {
            long hoursLeft = coinManager.getDailyCooldown(playerId);
            player.sendMessage(ChatColor.RED + "You can claim again in " + hoursLeft + " hours!");
        }
        return true;
    }
}