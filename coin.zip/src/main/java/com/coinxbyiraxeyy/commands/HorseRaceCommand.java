package com.coinxbyiraxeyy.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import com.coinxbyiraxeyy.managers.GameManager;
import org.bukkit.ChatColor;
import com.coinxbyiraxeyy.Main; // ✅ Add this

public class HorseRaceCommand implements CommandExecutor {
    private final GameManager gameManager;

    public HorseRaceCommand(Main plugin, GameManager gameManager) {
        this.gameManager = gameManager;
        plugin.getCommand("horserace").setExecutor(this);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Only players can use this command!");
            return true;
        }

        Player player = (Player) sender;

        if (args.length < 2) {
            player.sendMessage(ChatColor.RED + "Usage: /horserace <amount> <horse 1-5>");
            player.sendMessage(ChatColor.GOLD + "Horses: 1=Thunder, 2=Lightning, 3=Storm, 4=Blaze, 5=Shadow");
            return true;
        }

        try {
            int amount = Integer.parseInt(args[0]);
            int horse = Integer.parseInt(args[1]);

            if (amount <= 0) {
                player.sendMessage(ChatColor.RED + "Bet amount must be positive!");
                return true;
            }

            if (horse < 1 || horse > 5) {
                player.sendMessage(ChatColor.RED + "Horse must be between 1-5!");
                return true;
            }

            gameManager.startHorseRace(player, amount, horse);
        } catch (NumberFormatException e) {
            player.sendMessage(ChatColor.RED + "Invalid number format!");
        }

        return true;
    }
}
