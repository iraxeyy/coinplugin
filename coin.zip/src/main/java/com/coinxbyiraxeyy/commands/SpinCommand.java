package com.yourplugin.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import com.yourplugin.managers.GameManager;

public class SpinCommand implements CommandExecutor {
    private final GameManager gameManager;
    
    public SpinCommand(Main plugin, GameManager gameManager) {
        this.gameManager = gameManager;
        plugin.getCommand("spin").setExecutor(this);
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Only players can use this command!");
            return true;
        }
        
        Player player = (Player) sender;
        int bet = 100; // Default bet
        
        if (args.length > 0) {
            try {
                bet = Integer.parseInt(args[0]);
            } catch (NumberFormatException e) {
                player.sendMessage("Invalid bet amount!");
                return true;
            }
        }
        
        boolean won = gameManager.spin(player, bet);
        player.sendMessage(won ? "You won!" : "You lost. Try again!");
        
        return true;
    }
}