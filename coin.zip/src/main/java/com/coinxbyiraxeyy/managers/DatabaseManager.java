package com.coinxbyiraxeyy.managers;

import org.bukkit.plugin.java.JavaPlugin;
import java.sql.*;
import java.util.UUID;

public class DatabaseManager {
    private Connection connection;
    private final JavaPlugin plugin;

    public DatabaseManager(JavaPlugin plugin) {
        this.plugin = plugin;
        initializeDatabase();
    }

    private void initializeDatabase() {
        try {
            Class.forName("org.sqlite.JDBC");
            String dbPath = plugin.getDataFolder().getAbsolutePath() + "/player_data.db";
            connection = DriverManager.getConnection("jdbc:sqlite:" + dbPath);
            
            try (Statement stmt = connection.createStatement()) {
                stmt.execute("CREATE TABLE IF NOT EXISTS player_data (" +
                    "uuid TEXT PRIMARY KEY, " +
                    "coins INTEGER DEFAULT 0, " +
                    "discord_id TEXT, " +
                    "last_daily INTEGER DEFAULT 0)");
            }
        } catch (Exception e) {
            plugin.getLogger().severe("Database error: " + e.getMessage());
        }
    }

    public int getCoins(UUID uuid) {
        try (PreparedStatement stmt = connection.prepareStatement(
                "SELECT coins FROM player_data WHERE uuid = ?")) {
            stmt.setString(1, uuid.toString());
            ResultSet rs = stmt.executeQuery();
            return rs.next() ? rs.getInt("coins") : 0;
        } catch (SQLException e) {
            plugin.getLogger().warning("Error getting coins: " + e.getMessage());
            return 0;
        }
    }

    public void addCoins(UUID uuid, int amount) {
        setCoins(uuid, getCoins(uuid) + amount);
    }

    public void setCoins(UUID uuid, int amount) {
        try (PreparedStatement stmt = connection.prepareStatement(
                "INSERT OR REPLACE INTO player_data (uuid, coins) VALUES (?, ?)")) {
            stmt.setString(1, uuid.toString());
            stmt.setInt(2, amount);
            stmt.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().warning("Error setting coins: " + e.getMessage());
        }
    }

    public void setLastDaily(UUID uuid, long timestamp) {
        try (PreparedStatement stmt = connection.prepareStatement(
                "UPDATE player_data SET last_daily = ? WHERE uuid = ?")) {
            stmt.setLong(1, timestamp);
            stmt.setString(2, uuid.toString());
            stmt.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().warning("Error setting last daily: " + e.getMessage());
        }
    }

    public long getLastDaily(UUID uuid) {
        try (PreparedStatement stmt = connection.prepareStatement(
                "SELECT last_daily FROM player_data WHERE uuid = ?")) {
            stmt.setString(1, uuid.toString());
            ResultSet rs = stmt.executeQuery();
            return rs.next() ? rs.getLong("last_daily") : 0;
        } catch (SQLException e) {
            plugin.getLogger().warning("Error getting last daily: " + e.getMessage());
            return 0;
        }
    }

    public void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            plugin.getLogger().warning("Error closing connection: " + e.getMessage());
        }
    }
}