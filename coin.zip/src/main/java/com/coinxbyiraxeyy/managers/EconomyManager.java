package com.coinxbyiraxeyy.managers;

import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import java.util.UUID;

public class EconomyManager {
    private final JavaPlugin plugin;
    private final DatabaseManager databaseManager;
    
    public EconomyManager(JavaPlugin plugin, DatabaseManager databaseManager) {
        this.plugin = plugin;
        this.databaseManager = databaseManager;
    }
    
    public int getBalance(Player player) {
        return databaseManager.getCoins(player.getUniqueId());
    }
    
    public boolean hasEnough(Player player, int amount) {
        return getBalance(player) >= amount;
    }
    
    public void addCoins(Player player, int amount) {
        int current = getBalance(player);
        databaseManager.updateCoins(player.getUniqueId(), current + amount);
        
        // Log transaction
        logTransaction(player.getUniqueId(), amount, "WIN", "Game winnings");
    }
    
    public void removeCoins(Player player, int amount) {
        int current = getBalance(player);
        databaseManager.updateCoins(player.getUniqueId(), Math.max(0, current - amount));
        
        // Log transaction
        logTransaction(player.getUniqueId(), -amount, "LOSE", "Game bet");
    }
    
    public boolean giveDaily(Player player) {
        // Check last daily and give reward if eligible
        // Implementation depends on your database structure
        return true;
    }
    
    private void logTransaction(UUID uuid, int amount, String type, String description) {
        // Implement transaction logging
    }
}