package com.yourplugin.managers;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.*;
import org.bukkit.plugin.java.JavaPlugin;
import java.util.UUID;

public class LeaderboardManager {
    private final JavaPlugin plugin;
    private final CoinManager coinManager;

    public LeaderboardManager(JavaPlugin plugin, CoinManager coinManager) {
        this.plugin = plugin;
        this.coinManager = coinManager;
    }

    public void updateScoreboard(Player player) {
        Scoreboard scoreboard = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective objective = scoreboard.registerNewObjective("coins", "dummy", "§6§lPlayer Stats");
        objective.setDisplaySlot(DisplaySlot.SIDEBAR);

        Score name = objective.getScore("§aName: §f" + player.getName());
        name.setScore(3);

        int coins = coinManager.getCoins(player.getUniqueId());
        Score balance = objective.getScore("§bCoins: §f" + coins);
        balance.setScore(2);

        Score blank = objective.getScore(" ");
        blank.setScore(1);

        player.setScoreboard(scoreboard);
    }

    public void updateAllScoreboards() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            updateScoreboard(player);
        }
    }
}