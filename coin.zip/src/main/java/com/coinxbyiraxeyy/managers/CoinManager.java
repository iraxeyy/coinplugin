package com.coinxbyiraxeyy.managers;
import java.util.UUID;
public class CoinManager {
    public CoinManager(org.bukkit.plugin.Plugin p, DatabaseManager db) {}
    public int getCoins(UUID uuid) { return 1000; }
    public boolean canClaimDaily(UUID uuid) { return true; }
    public void giveDailyReward(UUID uuid) {}
    public void addCoins(UUID uuid, int amount) {}
    public void removeCoins(UUID uuid, int amount) {}
}