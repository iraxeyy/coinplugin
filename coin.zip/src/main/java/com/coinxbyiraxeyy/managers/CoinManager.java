package com.coinxbyiraxeyy.managers;

import org.bukkit.plugin.java.JavaPlugin;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

public class CoinManager {
    private final JavaPlugin plugin;
    private final DatabaseManager databaseManager;

    public CoinManager(JavaPlugin plugin, DatabaseManager databaseManager) {
        this.plugin = plugin;
        this.databaseManager = databaseManager;
    }

    public JavaPlugin getPlugin() {
        return plugin;
    }

    public int getCoins(UUID playerId) {
        return databaseManager.getCoins(playerId);
    }

    public void addCoins(UUID playerId, int amount) {
        databaseManager.addCoins(playerId, amount);
    }

    public boolean removeCoins(UUID playerId, int amount) {
        int current = getCoins(playerId);
        if (current >= amount) {
            databaseManager.setCoins(playerId, current - amount);
            return true;
        }
        return false;
    }

    public void giveDailyReward(UUID playerId) {
        addCoins(playerId, plugin.getConfig().getInt("economy.daily-reward"));
    }
}