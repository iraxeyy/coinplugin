
package com.coinxbyiraxeyy.managers;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import java.util.Random;
import java.util.UUID;
import com.coinxbyiraxeyy.managers.CoinManager;

public class GameManager {
    private final CoinManager coinManager;
    private final Random random = new Random();

    public GameManager(CoinManager coinManager) {
        this.coinManager = coinManager;
    }

    public void placeBet(Player player, int amount, int guess) {
        UUID uuid = player.getUniqueId();
        int balance = coinManager.getCoins(uuid);
        if (balance < amount) {
            player.sendMessage(ChatColor.RED + "You don't have enough coins to place this bet.");
            return;
        }

        int result = random.nextInt(100) + 1;
        if (guess == result) {
            int reward = amount * 2;
            coinManager.addCoins(uuid, reward);
            player.sendMessage(ChatColor.GREEN + "Congratulations! You guessed correctly and won " + reward + " coins!");
        } else {
            coinManager.removeCoins(uuid, amount);
            player.sendMessage(ChatColor.RED + "Sorry, you guessed " + guess + " but the number was " + result + ". Better luck next time!");
        }
    }

    public void startHorseRace(Player player, int amount, int chosenHorse) {
        UUID uuid = player.getUniqueId();
        int balance = coinManager.getCoins(uuid);
        if (balance < amount) {
            player.sendMessage(ChatColor.RED + "You don't have enough coins to join this race.");
            return;
        }

        int winningHorse = random.nextInt(5) + 1;
        if (chosenHorse == winningHorse) {
            int reward = amount * 4;
            coinManager.addCoins(uuid, reward);
            player.sendMessage(ChatColor.GOLD + "🏇 Horse #" + winningHorse + " won! You earned " + reward + " coins!");
        } else {
            coinManager.removeCoins(uuid, amount);
            player.sendMessage(ChatColor.RED + "Horse #" + winningHorse + " won. You lost your bet.");
        }
    }
}
