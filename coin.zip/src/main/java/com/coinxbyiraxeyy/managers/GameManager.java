// In GameManager.java
public boolean placeBet(Player player, int amount, int guess) {
    if (guess < 1 || guess > 100) {
        player.sendMessage("§cGuess must be between 1-100");
        return false;
    }

    if (!economyManager.hasEnough(player, amount)) {
        player.sendMessage("§cYou don't have enough coins!");
        return false;
    }

    economyManager.removeCoins(player, amount);
    int winningNumber = random.nextInt(100) + 1;

    if (guess == winningNumber) {
        int winnings = amount * 10;
        economyManager.addCoins(player, winnings);
        player.sendMessage("§aJackpot! You won §6" + winnings + " coins§a! (Number was " + winningNumber + ")");
        return true;
    } else if (Math.abs(guess - winningNumber) <= 10) {
        int winnings = amount * 2;
        economyManager.addCoins(player, winnings);
        player.sendMessage("§aClose! You won §6" + winnings + " coins§a! (Number was " + winningNumber + ")");
        return true;
    }

    player.sendMessage("§cYou lost. The number was " + winningNumber);
    return false;
}

public boolean startHorseRace(Player player, int bet, int horse) {
    if (cooldowns.containsKey(player) && System.currentTimeMillis() - cooldowns.get(player) < 30000) {
        player.sendMessage("§cYou must wait 30 seconds between races!");
        return false;
    }

    if (!economyManager.hasEnough(player, bet)) {
        player.sendMessage("§cYou don't have enough coins!");
        return false;
    }

    economyManager.removeCoins(player, bet);
    cooldowns.put(player, System.currentTimeMillis());

    int winner = random.nextInt(5) + 1;
    if (horse == winner) {
        int winnings = bet * 5;
        economyManager.addCoins(player, winnings);
        player.sendMessage("§aYour horse won! You earned §6" + winnings + " coins§a!");
        return true;
    }

    player.sendMessage("§cYour horse lost. Winner was horse #" + winner);
    return false;
}