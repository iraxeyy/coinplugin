package com.coinxbyiraxeyy.managers;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import java.util.Arrays;

public class ShopManager {
    private final JavaPlugin plugin;
    private final CoinManager coinManager;
    private Inventory shopInventory;

    public ShopManager(JavaPlugin plugin, CoinManager coinManager) {
        this.plugin = plugin;
        this.coinManager = coinManager;
        createShop();
    }

    private void createShop() {
        shopInventory = Bukkit.createInventory(null, 27, "§6Coin Shop");
        
        // Add shop items
        addShopItem(Material.DIAMOND, 10, "§bDiamond", 1, 10);
        addShopItem(Material.EMERALD, 12, "§aEmerald", 1, 5);
        addShopItem(Material.GOLDEN_APPLE, 14, "§6Golden Apple", 1, 15);
        addShopItem(Material.NETHERITE_INGOT, 16, "§4Netherite Ingot", 1, 50);
    }

    private void addShopItem(Material material, int slot, String name, int amount, int price) {
        ItemStack item = new ItemStack(material, amount);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore(Arrays.asList("§7Price: §a" + price + " coins"));
        item.setItemMeta(meta);
        shopInventory.setItem(slot, item);
    }

    public void openShop(Player player) {
        player.openInventory(shopInventory);
    }

    public boolean handlePurchase(Player player, int slot) {
        ItemStack item = shopInventory.getItem(slot);
        if (item == null) return false;

        int price = getPriceFromLore(item);
        if (price == -1) return false;

        if (coinManager.removeCoins(player.getUniqueId(), price)) {
            player.getInventory().addItem(item.clone());
            player.sendMessage("§aPurchased " + item.getType().name().toLowerCase() + " for " + price + " coins!");
            return true;
        } else {
            player.sendMessage("§cYou don't have enough coins!");
            return false;
        }
    }

    private int getPriceFromLore(ItemStack item) {
        if (!item.hasItemMeta() || !item.getItemMeta().hasLore()) return -1;
        String lore = item.getItemMeta().getLore().get(0);
        try {
            return Integer.parseInt(lore.split(" ")[1]);
        } catch (Exception e) {
            return -1;
        }
    }

    public Inventory getInventory() {
        return shopInventory;
    }
}