package com.coinxbyiraxeyy.commands;

import com.coinxbyiraxeyy.managers.GameManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.ChatColor;

import java.util.Random;
import java.util.UUID;

public class SpinCommand implements CommandExecutor {
    private final GameManager gameManager;

    public SpinCommand(GameManager gameManager) {
        this.gameManager = gameManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Only players can use this command!");
            return true;
        }

        Player player = (Player) sender;
        UUID uuid = player.getUniqueId();
        Random random = new Random();
        int result = random.nextInt(3);

        if (result == 0) {
            player.sendMessage(ChatColor.RED + "You spun and got nothing.");
        } else {
            int reward = result * 50;
            gameManager.addCoins(uuid, reward);
            player.sendMessage(ChatColor.GREEN + "You spun and won " + reward + " coins!");
        }

        return true;
    }
}