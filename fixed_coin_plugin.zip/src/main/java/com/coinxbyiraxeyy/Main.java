package com.coinxbyiraxeyy;

import com.coinxbyiraxeyy.commands.*;
import com.coinxbyiraxeyy.managers.*;
import com.coinxbyiraxeyy.listeners.*;
import com.coinxbyiraxeyy.discord.DiscordBot;
import org.bukkit.plugin.java.JavaPlugin;

public class Main extends JavaPlugin {
    private DiscordBot discordBot;

    @Override
    public void onEnable() {
        DatabaseManager db = new DatabaseManager(this);
        CoinManager cm = new CoinManager(this, db);
        GameManager gm = new GameManager(cm);
        ShopManager sm = new ShopManager(this, cm);

        new BalanceCommand(cm);
        new DailyCommand(cm);
        new SpinCommand(gm);
        new BetCommand(gm);
        new HorseRaceCommand(gm);
        new ShopCommand(sm);
        new DiscordLinkCommand(getDiscordBot());

        getServer().getPluginManager().registerEvents(new JoinListener(), this);
        getServer().getPluginManager().registerEvents(new ChatListener(), this);
    }

    public DiscordBot getDiscordBot() {
        if (discordBot == null) {
            discordBot = new DiscordBot(new CoinManager(this, new DatabaseManager(this)), new DatabaseManager(this));
        }
        return discordBot;
    }
}