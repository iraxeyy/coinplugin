package com.coinxbyiraxeyy.managers;
import java.util.UUID;
public class DatabaseManager {
    public DatabaseManager(org.bukkit.plugin.Plugin p) {}
    public UUID getPlayerFromDiscord(String id) { return UUID.randomUUID(); }
    public void linkDiscordAccount(UUID uuid, String id) {}
}