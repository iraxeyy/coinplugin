package com.coinxbyiraxeyy.managers;

import org.bukkit.configuration.file.YamlConfiguration;
import java.io.File;
import java.io.IOException;
import java.util.UUID;

public class EconomyManager {
    private final File dataFile;
    private final YamlConfiguration data;

    public EconomyManager(File pluginFolder) {
        this.dataFile = new File(pluginFolder, "coins.yml");
        this.data = YamlConfiguration.loadConfiguration(dataFile);
    }

    public int getCoins(UUID uuid) {
        return data.getInt(uuid.toString(), 0);
    }

    public void setCoins(UUID uuid, int coins) {
        data.set(uuid.toString(), coins);
        save();
    }

    public void addCoins(UUID uuid, int amount) {
        setCoins(uuid, getCoins(uuid) + amount);
    }

    public void removeCoins(UUID uuid, int amount) {
        setCoins(uuid, Math.max(0, getCoins(uuid) - amount));
    }

    public void save() {
        try {
            data.save(dataFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}