package com.coinxbyiraxeyy.managers;
import org.bukkit.entity.Player;
public class GameManager {
    public GameManager(CoinManager cm) {}
    public void placeBet(Player p, int a, int n) {}
    public void startHorseRace(Player p, int a, int h) {}
}