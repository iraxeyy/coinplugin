package com.coinxbyiraxeyy.discord;

import com.coinxbyiraxeyy.managers.CoinManager;
import com.coinxbyiraxeyy.managers.DatabaseManager;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import net.dv8tion.jda.api.interactions.commands.build.Commands;
import net.dv8tion.jda.api.entities.User;
import javax.security.auth.login.LoginException;
import java.util.*;

public class DiscordBot extends ListenerAdapter {
    private JDA jda;
    private final CoinManager coinManager;
    private final DatabaseManager database;
    private final Map<String, UUID> pendingLinks = new HashMap<>();
    private final Map<String, String> triviaAnswers = new HashMap<>();

    public DiscordBot(CoinManager coinManager, DatabaseManager database) {
        this.coinManager = coinManager;
        this.database = database;
    }

    public void startBot(String token) throws LoginException {
        jda = JDABuilder.createDefault(token).addEventListeners(this).build();
        jda.updateCommands().addCommands(
            Commands.slash("link", "Link your Minecraft account")
                .addOption(net.dv8tion.jda.api.interactions.commands.OptionType.STRING, "code", "Enter code", true),
            Commands.slash("daily", "Claim your daily reward"),
            Commands.slash("balance", "Check balance"),
            Commands.slash("coinflip", "Flip a coin").addOption(
                net.dv8tion.jda.api.interactions.commands.OptionType.INTEGER, "amount", "Bet", true),
            Commands.slash("stats", "View stats"),
            Commands.slash("trivia", "Play trivia"),
            Commands.slash("bet", "Bet 1-100").addOption(
                net.dv8tion.jda.api.interactions.commands.OptionType.INTEGER, "amount", "Amount", true)
                .addOption(net.dv8tion.jda.api.interactions.commands.OptionType.INTEGER, "number", "Number", true),
            Commands.slash("horserace", "Pick horse").addOption(
                net.dv8tion.jda.api.interactions.commands.OptionType.INTEGER, "amount", "Bet", true)
                .addOption(net.dv8tion.jda.api.interactions.commands.OptionType.INTEGER, "horse", "Horse", true)
        ).queue();
    }

    @Override
    public void onSlashCommandInteraction(SlashCommandInteractionEvent event) {
        String cmd = event.getName();
        User user = event.getUser();
        if (cmd.equals("trivia")) {
            triviaAnswers.put(user.getId(), "C");
            event.reply("🧠 Trivia Time!
What is the capital of France?
A) Berlin
B) Madrid
C) Paris
D) Rome")
                .queue();
        }
    }

    @Override
    public void onMessageReceived(MessageReceivedEvent event) {
        if (event.getAuthor().isBot()) return;
        String id = event.getAuthor().getId();
        String answer = event.getMessage().getContentRaw().trim().toUpperCase();
        if (triviaAnswers.containsKey(id)) {
            String correct = triviaAnswers.remove(id);
            UUID uuid = database.getPlayerFromDiscord(id);
            if (uuid == null) {
                event.getChannel().sendMessage("❌ You must `/link` your account.").queue();
                return;
            }
            if (answer.equals(correct)) {
                coinManager.addCoins(uuid, 50);
                event.getChannel().sendMessage("✅ Correct! You earned 50 coins.").queue();
            } else {
                event.getChannel().sendMessage("❌ Incorrect. The correct answer was: "" + correct + """).queue();
            }
        }
    }

    public void shutdown() { if (jda != null) jda.shutdown(); }

    public String generateLinkCode(UUID uuid) {
        String code = UUID.randomUUID().toString().substring(0, 6);
        pendingLinks.put(code, uuid);
        new Timer().schedule(new TimerTask() {
            @Override public void run() { pendingLinks.remove(code); }
        }, 600_000);
        return code;
    }
}