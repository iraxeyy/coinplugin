/* 
/lb or /top command for Discord
- Lists top players from Minecraft by coin balance
- Shows 10 players per page
*/