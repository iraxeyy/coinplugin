/* 
/leaderboard command for Minecraft
- Lists top players by coin balance in chat
- Optionally displays as scoreboard (configurable)
*/